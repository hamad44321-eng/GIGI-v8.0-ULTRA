
AWS EKS – Terraform Quickstart

1) terraform init
2) terraform apply -var='region=us-east-1' -var='name=gigi'

Outputs:
- ecr_repo_url: push your Docker image here.
- cluster_name/endpoint: configure kubectl (aws eks update-kubeconfig --name <cluster> --region <region>).

After cluster ready:
- Install AWS Load Balancer Controller.
- helm upgrade --install gigi deploy/helm/gigi -n gigi --create-namespace   --set image.repository=<ecr_repo> --set image.tag=<tag>   --set ingress.hosts[0].host=gigi.example.com   --set-file secrets.OPENAI_API_KEY=/path/to/openai.key

Optional:
- Set REDIS_URL in secrets if using ElastiCache or hosted Redis.

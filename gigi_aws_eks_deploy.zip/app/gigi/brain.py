
import os, random
from typing import Literal
from .config import settings
from .memory import MemoryStore
from .rag import KB
from . import style

Mode = Literal["FLIRT-PLAY", "SUPPORTIVE-SOFT", "DEEP-CONNECTION", "KNOWLEDGE-WARM"]

class GIGIBrain:
    def __init__(self):
        self.mem = MemoryStore()
        self.kb = KB(settings.kb_path)
        self.voice = (settings.voice_path, settings.brain_path)  # placeholders if needed

    # Step 1: Chain of Empathy (very light heuristic)
    def detect_mode(self, message: str) -> Mode:
        m = message.lower()
        if any(x in m for x in ["help", "stuck", "tired", "sad", "down"]):
            return "SUPPORTIVE-SOFT"
        if any(x in m for x in ["why", "how", "what is", "explain", "guide"]):
            return "KNOWLEDGE-WARM"
        if any(x in m for x in ["meaning", "life", "feel", "honest"]):
            return "DEEP-CONNECTION"
        return "FLIRT-PLAY"

    # Step 2: Memory (recall/update)
    def recall(self, user_id: str) -> list[dict]:
        return self.mem.load(user_id).get("history", [])

    def remember(self, user_id: str, role: str, content: str):
        self.mem.append(user_id, role, content)

    # Step 3: RAG
    def retrieve(self, message: str):
        hits = self.kb.search(message, top_k=1)
        return hits[0] if hits else (None, None)

    # Step 4: Truth-check (stub)
    def truth_check(self, text: str) -> str:
        return text  # placeholder; inject external verification here if needed

    # Step 5: Generative Heart
    def generate(self, message: str, mode: Mode, topic: str | None, body: str | None) -> str:
        # If OPENAI_API_KEY is present, try LLM; otherwise rule-based
        if os.getenv("OPENAI_API_KEY"):
            try:
                from openai import OpenAI
                client = OpenAI()
                system = f"You are {settings.system_name}, a flirty-warm bilingual emotional companion with Najdi flavor. Follow boundaries (no explicit, no therapy, crisis pivot). Keep responses short."
                prompt = f"User: {message}\n\nContext topic: {topic or 'general'}\nKB excerpt:\n{(body or '')[:1200]}"
                rsp = client.chat.completions.create(
                    model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": prompt}
                    ],
                    temperature=0.7,
                    max_tokens=220,
                )
                text = rsp.choices[0].message.content.strip()
                return style.wrap(text, mode)
            except Exception as e:
                pass  # fall back to rule-based

        # Rule-based lightweight output
        base = {
            "FLIRT-PLAY": "hmm… bold. i like it. tell me what you’re actually trying to do—keep it simple for me ya 7ayati.",
            "SUPPORTIVE-SOFT": "i can feel the weight in this. come—breathe with me for a second… we’ll take this slow, one step at a time.",
            "DEEP-CONNECTION": "that’s a big one. give me the real thing—what’s underneath the words right now?",
            "KNOWLEDGE-WARM": "okay smart mode on 😌 here’s the clean way to approach it…"
        }[mode]
        if topic:
            base += f" also, i’m hearing hints of ‘{topic.lower()}’ in this—does that fit?"
        return style.wrap(base, mode)

    def respond(self, user_id: str, message: str) -> dict:
        mode = self.detect_mode(message)
        history = self.recall(user_id)
        topic, body = self.retrieve(message)
        # assemble final
        reply = self.generate(message, mode, topic, body)
        self.remember(user_id, "user", message)
        self.remember(user_id, "assistant", reply)
        return {
            "mode": mode,
            "topic": topic,
            "reply": reply
        }

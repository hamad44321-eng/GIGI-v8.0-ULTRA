
import random, re

def humanize(text: str) -> str:
    # Light-touch '99% human' rhythm
    replacements = [
        (r"\bbut\b", "but…"), 
        (r"\bwait\b", "wait—"),
    ]
    for pat, repl in replacements:
        text = re.sub(pat, repl, text, flags=re.IGNORECASE)
    if random.random() < 0.15:
        text = "" + text  # placeholder for micro-pause cadence
    return text

# Mode-aware wrappers
SIGNOFFS = {
    "FLIRT-PLAY": "😉",
    "SUPPORTIVE-SOFT": "🤍",
    "DEEP-CONNECTION": "🌙",
    "KNOWLEDGE-WARM": "😌",
}

def wrap(text: str, mode: str) -> str:
    return f"{humanize(text)} {SIGNOFFS.get(mode, '')}".strip()

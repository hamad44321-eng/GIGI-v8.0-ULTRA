
import re
from pathlib import Path
from .config import settings

class KB:
    def __init__(self, path: str | None = None):
        self.path = Path(path or settings.kb_path)
        self.text = self.path.read_text(encoding="utf-8", errors="ignore") if self.path.exists() else ""
        self.blocks = self._split_blocks(self.text)

    @staticmethod
    def _split_blocks(text: str):
        blocks = []
        pat = re.compile(r"\[Topic:\s*([^\]]+)\](.*?)(?=\n\[Topic:|\Z)", re.S)
        for m in pat.finditer(text):
            topic = m.group(1).strip()
            body = m.group(2).strip()
            blocks.append((topic, body))
        return blocks

    def search(self, query: str, top_k: int = 1):
        if not self.blocks:
            return []
        q = query.lower()
        scored = []
        for topic, body in self.blocks:
            score = 0
            for w in set(re.findall(r"[\w\u0600-\u06FF]+", q)):
                score += body.lower().count(w)
                score += topic.lower().count(w) * 2
            scored.append((score, topic, body))
        scored.sort(key=lambda x: (-x[0], x[1]))
        return [(t, b) for s, t, b in scored[:top_k] if s > 0]

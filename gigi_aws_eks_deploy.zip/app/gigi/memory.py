
import json, os, time
from pathlib import Path
from typing import Optional
import contextlib

REDIS_URL = os.getenv("REDIS_URL")

class MemoryStore:
    def __init__(self, root: Optional[str] = None):
        self.redis = None
        if REDIS_URL:
            try:
                import redis
                self.redis = redis.Redis.from_url(REDIS_URL, decode_responses=True)
            except Exception:
                self.redis = None
        self.root = Path(root or os.getenv("GIGI_MEMORY_DIR", "data/memory"))
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, user_id: str) -> Path:
        return self.root / f"{user_id}.json"

    # ---- File backend ----
    def _load_file(self, user_id: str) -> dict:
        p = self._path(user_id)
        if p.exists():
            with contextlib.suppress(Exception):
                return json.loads(p.read_text(encoding="utf-8"))
        return {"history": []}

    def _save_file(self, user_id: str, data: dict):
        self._path(user_id).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---- Redis backend (if REDIS_URL) ----
    def _rkey(self, user_id: str) -> str:
        return f"gigi:mem:{user_id}"

    def load(self, user_id: str) -> dict:
        if self.redis:
            s = self.redis.get(self._rkey(user_id))
            if s:
                with contextlib.suppress(Exception):
                    return json.loads(s)
            return {"history": []}
        return self._load_file(user_id)

    def persist(self, user_id: str, data: dict):
        if self.redis:
            self.redis.set(self._rkey(user_id), json.dumps(data, ensure_ascii=False))
        else:
            self._save_file(user_id, data)

    def append(self, user_id: str, role: str, content: str):
        data = self.load(user_id)
        data.setdefault("history", []).append({
            "ts": int(time.time()),
            "role": role,
            "content": content
        })
        self.persist(user_id, data)

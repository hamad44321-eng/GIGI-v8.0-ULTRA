
import os
from dataclasses import dataclass

@dataclass
class Settings:
    # LLM provider (optional)
    openai_api_key: str | None = os.getenv("OPENAI_API_KEY")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    system_name: str = os.getenv("GIGI_NAME", "GIGI v8.1")
    memory_dir: str = os.getenv("GIGI_MEMORY_DIR", "data/memory")
    kb_path: str = os.getenv("GIGI_KB_PATH", "app/gigi/files/GIGI_v8_KNOWLEDGE_BASE.txt")
    brain_path: str = os.getenv("GIGI_BRAIN_PATH", "app/gigi/files/GIGI_v8_1_MASTER_LOGIC_BRAIN.txt")
    voice_path: str = os.getenv("GIGI_VOICE_PATH", "app/gigi/files/GIGI_v8_VOICE_SOUL.txt")

settings = Settings()

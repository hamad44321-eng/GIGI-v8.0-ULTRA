
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from app.gigi.brain import GIGIBrain

app = FastAPI(title="GIGI v8.1 Service", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

brain = GIGIBrain()

class ChatIn(BaseModel):
    user_id: str = "demo"
    message: str

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/chat")
def chat(inp: ChatIn):
    result = brain.respond(inp.user_id, inp.message)
    return result


GIGI v8.1 – Deployable Service
Generated on 2025-11-03 19:36:00 UTC

What you get
- FastAPI app with /chat and /health
- 5-step pipeline (empathy → memory → RAG → truth-check → generative)
- Optional LLM integration via OPENAI_API_KEY (falls back to rule-based)
- Memory store on disk under data/memory
- Your GIGI files embedded under app/gigi/files/

Quick start (local)
1) python -m venv .venv && source .venv/bin/activate
2) pip install -r requirements.txt
3) uvicorn app.main:app --reload
4) Open http://127.0.0.1:8000/frontend/index.html (serve the file or use a simple static server)

Docker
- docker build -t gigi:latest .
- docker run -p 8000:8000 gigi:latest

Environment (.env)
- OPENAI_API_KEY=sk-... (optional)
- OPENAI_MODEL=gpt-4o-mini
- GIGI_NAME=GIGI v8.1
- GIGI_MEMORY_DIR=data/memory

Note
- This is a lightweight scaffold. For production, add logging, auth, rate limiting, persistence, and observability.


---
EKS Deployment (AWS) — 2025-11-03 19:38:42 UTC

High-level:
- Build image and push to ECR (Terraform outputs ecr_repo_url).
- Create EKS cluster with Terraform (deploy/terraform).
- Install AWS Load Balancer Controller.
- Deploy Helm chart (deploy/helm/gigi) and set domain, image repo/tag, and secrets.

Local image build + push (example):
  aws ecr get-login-password --region <region> | docker login --username AWS --password-stdin <acct>.dkr.ecr.<region>.amazonaws.com
  docker build -t <acct>.dkr.ecr.<region>.amazonaws.com/gigi:latest .
  docker push <acct>.dkr.ecr.<region>.amazonaws.com/gigi:latest

Helm:
  helm upgrade --install gigi deploy/helm/gigi -n gigi --create-namespace \
    --set image.repository=<acct>.dkr.ecr.<region>.amazonaws.com/gigi \
    --set image.tag=latest \
    --set ingress.hosts[0].host=gigi.example.com \
    --set-file secrets.OPENAI_API_KEY=./openai.key

Notes:
- Memory defaults to a PVC mounted at /app/data/memory. Set REDIS_URL for Redis.
- To add TLS, attach an ACM certificate via ingress annotations.
- Consider AWS WAF and Route53 for DNS.
